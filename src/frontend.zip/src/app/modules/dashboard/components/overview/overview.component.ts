import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-dashboard-overview',
  templateUrl: './overview.component.html',
})
export class OverviewComponent implements OnInit {
  items = [];

  constructor(

  ) {

  }


  ngOnInit(): void {

  }


}

