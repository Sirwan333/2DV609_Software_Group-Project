export class ShowSidebarAction {
  static readonly type = '[Sidebar] Show sidebar action';
}

export class HideSidebarAction {
  static readonly type = '[Sidebar] Hide sidebar action';
}

export class ToggleSidebarAction {
  static readonly type = '[Sidebar] Toggle sidebar action';
}
