export class ShowLoaderAction {
  static readonly type = '[Loader] Show loader action';
}

export class HideLoaderAction {
  static readonly type = '[Loader] Hide loader action';
}
