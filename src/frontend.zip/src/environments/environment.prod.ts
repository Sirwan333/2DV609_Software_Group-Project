export const environment = {
  production: true,
  baseAPI: '/api/v1/'
}
